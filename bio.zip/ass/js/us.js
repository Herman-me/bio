function askNY(){
	confirm("آیا اطمینان دارید ؟");
}